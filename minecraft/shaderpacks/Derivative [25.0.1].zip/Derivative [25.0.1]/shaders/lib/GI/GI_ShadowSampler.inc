/*
================================================================================
  GI_ShadowSampler.inc  —  Shadow map sampling helpers
  =====================================================

  Единое место для:
    • DistortionFactor (переопределяем если нужно)
    • Конвертация world → shadow → UV
    • Функции для выборки depth / normal / albedo из shadow map
================================================================================
*/

#ifndef GI_SHADOW_SAMPLER_INC
#define GI_SHADOW_SAMPLER_INC


// Переиспользуем DistortionFactor из Material.inc / ShadowDistortion.glsl
// (они уже включены раньше в шейдерную цепочку)

// Вернуть UV (0..1) из shadow-clip coords (уже после дисторции)
vec2 GI_ShadowClipToUV(vec2 clipXY) {
    float df = DistortionFactor(clipXY);
    return DistortShadowSpace(vec3(clipXY, 0.0), df).xy * 0.5 + 0.5;
}

// Texel из UV
ivec2 GI_UVToTexel(vec2 uv, float mapRes) {
    return ivec2(uv * mapRes);
}

// Безопасный texel: зажимаем в пределы карты
ivec2 GI_ClipTexel(ivec2 texel, float mapRes) {
    return clamp(texel, ivec2(0), ivec2(int(mapRes) - 1));
}

#endif // GI_SHADOW_SAMPLER_INC
