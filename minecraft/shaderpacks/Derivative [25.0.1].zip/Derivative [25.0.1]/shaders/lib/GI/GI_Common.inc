/*
================================================================================
  GI_Common.inc  —  Shared math, structs, sampling for the Advanced GI System
  =============================================================================

  Включает:
    • Структуры Reservoir, SHBand2, RadianceProbe
    • ONB, косинусное + GGX сэмплирование
    • Хэши: IGN, R2, Fibonacci
    • SH2 (4 коэффициента L0+L1) — проекция, эвалюация
    • Тонмаппинг сэмплов (анти-firefly)
    • Общие утилиты: view/world/shadow конвертации

  Используется всеми GI-файлами.
================================================================================
*/

#ifndef GI_COMMON_INC
#define GI_COMMON_INC

// ─────────────────────────────────────────────────────────────────────────────
// Константы
// ─────────────────────────────────────────────────────────────────────────────

#ifndef PI
    #define PI  3.14159265358979323846
#endif
#ifndef TAU
    #define TAU 6.28318530717958647692
#endif
#ifndef rPI
    #define rPI 0.31830988618379067154
#endif
#define PHI     1.61803398874989484820
#define SQRT2   1.41421356237309504880
#define rSQRT2  0.70710678118654752440

// ─────────────────────────────────────────────────────────────────────────────
// Структура Reservoir (WRS / RIS)
// ─────────────────────────────────────────────────────────────────────────────

struct GI_Reservoir {
    float  W;          // Unbiased contribution weight W = w_sum / (M * p̂)
    float  targetPdf;  // p̂(y) выбранного сэмпла
    float  M;          // Количество обработанных кандидатов (confidence)
    vec3   radiance;   // Цвет / irradiance выбранного сэмпла
    vec3   hitPos;     // World/view-space позиция хита (для репроекции)
    vec3   hitNormal;  // Нормаль в точке хита
};

GI_Reservoir GI_ReservoirCreate() {
    GI_Reservoir r;
    r.W = 0.0; r.targetPdf = 1e-8; r.M = 0.0;
    r.radiance  = vec3(0.0);
    r.hitPos    = vec3(0.0);
    r.hitNormal = vec3(0.0, 1.0, 0.0);
    return r;
}

// Один шаг WRS. Возвращает true если кандидат принят.
bool GI_ReservoirUpdate(inout GI_Reservoir r,
                        float w_i, vec3 radiance, vec3 hitPos, vec3 hitNormal,
                        float xi)
{
    r.W += w_i;
    r.M += 1.0;
    if (xi * r.W < w_i) {
        r.radiance  = radiance;
        r.hitPos    = hitPos;
        r.hitNormal = hitNormal;
        return true;
    }
    return false;
}

// Объединение двух reservoir (spatial/temporal reuse).
void GI_ReservoirMerge(inout GI_Reservoir dst, in GI_Reservoir src, float xi) {
    float contribution = src.targetPdf * src.W * src.M;
    if (contribution <= 0.0) return;
    dst.W += contribution;
    dst.M += src.M;
    if (xi * dst.W < contribution) {
        dst.radiance  = src.radiance;
        dst.hitPos    = src.hitPos;
        dst.hitNormal = src.hitNormal;
        dst.targetPdf = src.targetPdf;
    }
}

float GI_ReservoirFinalW(in GI_Reservoir r) {
    return r.W / max(r.M * r.targetPdf, 1e-8);
}

// ─────────────────────────────────────────────────────────────────────────────
// Структура SH Band-2 (L0 + L1: 4 коэффициента на канал)
// ─────────────────────────────────────────────────────────────────────────────

struct SH2 {
    vec3 c[4];   // c[0]=L0, c[1..3]=L1 (y, z, x basis)
};

SH2 SH2_Zero() {
    SH2 s;
    s.c[0] = s.c[1] = s.c[2] = s.c[3] = vec3(0.0);
    return s;
}

// Проекция направления + цвета в SH2
SH2 SH2_Project(vec3 dir, vec3 radiance) {
    SH2 s;
    // L0
    s.c[0] = radiance * 0.282095;
    // L1 (y, z, x)
    s.c[1] = radiance * 0.488603 * dir.y;
    s.c[2] = radiance * 0.488603 * dir.z;
    s.c[3] = radiance * 0.488603 * dir.x;
    return s;
}

SH2 SH2_Add(SH2 a, SH2 b) {
    SH2 s;
    s.c[0] = a.c[0] + b.c[0];
    s.c[1] = a.c[1] + b.c[1];
    s.c[2] = a.c[2] + b.c[2];
    s.c[3] = a.c[3] + b.c[3];
    return s;
}

SH2 SH2_Scale(SH2 a, float t) {
    SH2 s;
    s.c[0] = a.c[0] * t;
    s.c[1] = a.c[1] * t;
    s.c[2] = a.c[2] * t;
    s.c[3] = a.c[3] * t;
    return s;
}

// Эвалюация SH2 в направлении dir (косинусный lobe)
vec3 SH2_Eval(in SH2 s, vec3 dir) {
    // ZH convolution с косинусным lobe (L0 * π, L1 * 2π/3)
    vec3 result = s.c[0] * 3.141593    // L0 * π
                + s.c[1] * 2.094395 * dir.y
                + s.c[2] * 2.094395 * dir.z
                + s.c[3] * 2.094395 * dir.x;
    return max(result, vec3(0.0));
}

// ─────────────────────────────────────────────────────────────────────────────
// Псевдослучайные числа
// ─────────────────────────────────────────────────────────────────────────────

// Interleaved Gradient Noise (Jimenez 2014) — плавный, дружелюбен к TAA
float GI_IGN(vec2 fragCoord) {
    return fract(52.9829189 * fract(dot(fragCoord, vec2(0.06711056, 0.00583715))));
}

// R2 sequence (Roberts)
float GI_R2(uint i) {
    return fract(float(i) * 0.618033988749895);
}

vec2 GI_R2_2D(uint i) {
    return fract(vec2(float(i)) * vec2(0.754877666246693, 0.569840290998));}

// Fibonacci spiral — равномерное покрытие диска
vec2 GI_FibSpiral(uint i, uint n, float jitter) {
    float fi    = (float(i) + jitter) / float(n);
    float angle = float(i) * 2.3999632 /* TAU/PHI */;
    return vec2(cos(angle), sin(angle)) * sqrt(fi);
}

// Hash без синуса (Hashes without Sine, David Hoskins)
float GI_Hash1(float p) {
    p = fract(p * 0.1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

float GI_Hash1(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 GI_Hash2(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

// ─────────────────────────────────────────────────────────────────────────────
// Ортонормальный базис (ONB) — метод Frisvad / Duff et al. 2017
// ─────────────────────────────────────────────────────────────────────────────

void GI_BuildONB(vec3 N, out vec3 T, out vec3 B) {
    float s  = (N.z >= 0.0) ? 1.0 : -1.0;
    float a  = -1.0 / (s + N.z);
    float b  = N.x * N.y * a;
    T = vec3(1.0 + s * N.x * N.x * a, s * b, -s * N.x);
    B = vec3(b, s + N.y * N.y * a, -N.y);
}

// Применяем ONB
vec3 GI_LocalToWorld(vec3 local, vec3 N) {
    vec3 T, B;
    GI_BuildONB(N, T, B);
    return local.x * T + local.y * B + local.z * N;
}

// ─────────────────────────────────────────────────────────────────────────────
// Сэмплирование направлений
// ─────────────────────────────────────────────────────────────────────────────

// Косинусно-взвешенная полусфера (Malley's method)
vec3 GI_CosineSample(vec3 N, vec2 xi) {
    float phi  = xi.x * TAU;
    float sinT = sqrt(max(xi.y, 0.0));
    float cosT = sqrt(max(1.0 - xi.y, 0.0));
    vec3 local = vec3(sinT * cos(phi), sinT * sin(phi), cosT);
    return GI_LocalToWorld(local, N);
}

// GGX (VNDF — Visible Normal Distribution Function, Heitz 2018)
vec3 GI_GGX_VNDF_Sample(vec3 V, float roughness, vec2 xi) {
    float a2 = roughness * roughness;
    // Stretch view dir
    vec3 Vh = normalize(vec3(a2 * V.x, a2 * V.y, V.z));
    // Build ONB around Vh
    float lensq = dot(Vh.xy, Vh.xy);
    vec3 T1 = (lensq > 0.0) ? vec3(-Vh.y, Vh.x, 0.0) * inversesqrt(lensq)
                              : vec3(1.0, 0.0, 0.0);
    vec3 T2 = cross(Vh, T1);
    float r   = sqrt(xi.x);
    float phi = TAU * xi.y;
    float t1  = r * cos(phi);
    float t2  = r * sin(phi);
    float s   = 0.5 * (1.0 + Vh.z);
    t2 = mix(sqrt(1.0 - t1 * t1), t2, s);
    vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(1.0 - t1*t1 - t2*t2, 0.0)) * Vh;
    vec3 H  = normalize(vec3(a2 * Nh.x, a2 * Nh.y, max(Nh.z, 0.0)));
    return H;
}

// Uniform sphere
vec3 GI_UniformSphereSample(vec2 xi) {
    float phi   = TAU * xi.x;
    float cosT  = 1.0 - 2.0 * xi.y;
    float sinT  = sqrt(max(1.0 - cosT * cosT, 0.0));
    return vec3(sinT * cos(phi), sinT * sin(phi), cosT);
}

// ─────────────────────────────────────────────────────────────────────────────
// Яркость и тонмаппинг сэмплов (анти-firefly)
// ─────────────────────────────────────────────────────────────────────────────

float GI_Luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// Рейнхардт на яркость — сохраняет chromaticity
vec3 GI_TonemapSample(vec3 c) {
    float L  = GI_Luma(c);
    float L2 = L / (1.0 + L);
    return c * (L2 / max(L, 1e-5));
}

vec3 GI_InvTonemapSample(vec3 c) {
    float L  = GI_Luma(c);
    float L2 = L / max(1.0 - L, 1e-4);
    return c * (L2 / max(L, 1e-5));
}

// ─────────────────────────────────────────────────────────────────────────────
// Конвертации пространств (переиспользуем функции из Functions.inc)
// ─────────────────────────────────────────────────────────────────────────────

// Shadow-map projection (inline-friendly)
vec3 GI_WorldToShadow(vec3 worldPos) {
    return projMAD(shadowProjection,
           transMAD(shadowModelView, worldPos));
}

float GI_DistortionFactor(vec2 sp) {
    return sqrt(sqrt(pow(abs(sp.x), 4.0) + pow(abs(sp.y), 4.0))) * SHADOW_MAP_BIAS
           + 1.0 - SHADOW_MAP_BIAS;
}

vec2 GI_ShadowToUV(vec2 sp) {
    float df = GI_DistortionFactor(sp);
    return sp * rcp(df) * 0.5 + 0.5;
}

// ─────────────────────────────────────────────────────────────────────────────
// Проверка геометрической совместимости (для reuse)
// ─────────────────────────────────────────────────────────────────────────────

bool GI_GeomCompatible(vec3 N0, float depth0, vec3 N1, float depth1,
                        float normalThresh, float depthThresh)
{
    float ndot = dot(N0, N1);
    float ddif = abs(depth0 - depth1) / max(depth0, 1e-3);
    return (ndot > normalThresh) && (ddif < depthThresh);
}

// ─────────────────────────────────────────────────────────────────────────────
// Вспомогательные макро-утилиты
// ─────────────────────────────────────────────────────────────────────────────

#define GI_SafeLen(v)      sqrt(max(dot(v, v), 1e-10))
#define GI_SafeNorm(v)     ((v) / GI_SafeLen(v))
#define GI_Saturate(x)     clamp(x, 0.0, 1.0)
#define GI_Clamp16F(x)     clamp(x, 0.0, 65535.0)

// Fast exponential base-2
#define GI_expf2(x)     exp2(x)
#define GI_expf(x)      exp2((x) * 1.4426950408889634)

#endif // GI_COMMON_INC
