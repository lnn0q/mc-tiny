// Тоглы шейдинга стекла (portal-like рефракция/блик для translucent glass).
// Регистрируются в shaders.properties -> screen.Transparent

#define GLASS_SHADING // Шейдинг (рефракция + френелевский блик) цветного и обычного стекла [Iris toggle]
#define MOD_GLASS_SHADING // Распространяет GLASS_SHADING также на стекло из модов [Iris toggle]
